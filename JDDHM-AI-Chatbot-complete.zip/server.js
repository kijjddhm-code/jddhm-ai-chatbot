import express from "express";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

if (!process.env.GEMINI_API_KEY) {
  console.error("ERROR: GEMINI_API_KEY is missing from .env");
  process.exit(1);
}

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

app.use(express.json({ limit: "10mb" }));
app.use(express.static("public"));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, model: MODEL });
});

app.post("/api/chat", async (req, res) => {
  try {
    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    if (!messages.length) return res.status(400).json({ error: "No message provided." });

    const contents = messages.map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: String(m.content || "") }]
    }));

    let response;
    let lastError;

    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        response = await ai.models.generateContent({ model: MODEL, contents });
        break;
      } catch (err) {
        lastError = err;
        console.error(`Gemini attempt ${attempt} failed:`, err?.message || err);
        if (attempt < 3 && [429, 500, 503].includes(err?.status)) {
          await new Promise((r) => setTimeout(r, attempt * 2500));
        } else {
          break;
        }
      }
    }

    if (!response) {
      const status = lastError?.status || 500;
      const message = lastError?.message || "Gemini request failed.";
      return res.status(status >= 400 && status < 600 ? status : 500).json({ error: message });
    }

    res.json({ reply: response.text || "No response from Gemini." });
  } catch (err) {
    console.error("Chat error:", err);
    res.status(500).json({ error: err?.message || "Chat request failed." });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`JDDHM AI Chatbot running at http://localhost:${PORT}`);
});
