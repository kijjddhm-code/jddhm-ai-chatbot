# JDDHM AI Chatbot

## Run on Termux or computer

1. Install Node.js.
2. Put these files in one folder.
3. Run:
   npm install
4. Copy `.env.example` to `.env` and put your Gemini API key in it.
5. Start:
   npm start
6. Open http://localhost:3000

## Important
- The API key stays on the server; do not put it in `index.html` or `script.js`.
- The 20-message limit, login/account UI, and MoMo upgrade screen in this starter are local/demo features. They are NOT secure payment or authentication systems.
- File text extraction works best for plain-text files. PDF/DOC files are only selected unless you add dedicated parsers.
- The Image button creates an image prompt. Actual image generation needs an image-capable API/model and a server endpoint.
- The Links button opens a web search; it is not server-side web browsing.
