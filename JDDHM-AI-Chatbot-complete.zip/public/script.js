const $=s=>document.querySelector(s);
const messagesEl=$("#messages"), input=$("#input"), typing=$("#typing"), welcome=$("#welcome");
let history=JSON.parse(localStorage.getItem("jddhm_history")||"[]");
let recent=JSON.parse(localStorage.getItem("jddhm_recent")||"[]");
let usage=Number(localStorage.getItem("jddhm_usage")||0), fileText="";
let accountMode="login", deferredInstall=null;

function save(){localStorage.setItem("jddhm_history",JSON.stringify(history));localStorage.setItem("jddhm_recent",JSON.stringify(recent));localStorage.setItem("jddhm_usage",usage)}
function toast(t){const e=$("#toast");e.textContent=t;e.hidden=false;setTimeout(()=>e.hidden=true,2600)}
function updateUsage(){ $("#usage").textContent=`${usage} / 20`; $("#progress").style.width=Math.min(usage/20*100,100)+"%"; save(); }
function esc(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function addMessage(role,text){const row=document.createElement("div");row.className=`msg ${role}`;row.innerHTML=`<div class="bubble">${esc(text)}<div class="actions">${role==="assistant"?'<button data-copy>Copy</button><button data-share>Share</button><button data-download>Download</button>':""}</div></div>`;messagesEl.appendChild(row);row.querySelector("[data-copy]")?.addEventListener("click",()=>navigator.clipboard?.writeText(text).then(()=>toast("Copied")));row.querySelector("[data-share]")?.addEventListener("click",()=>navigator.share?navigator.share({title:"AI Chatbot",text}):navigator.clipboard?.writeText(text).then(()=>toast("Sharing not available — copied instead")));row.querySelector("[data-download]")?.addEventListener("click",()=>{const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([text],{type:"text/plain"}));a.download="ai-chatbot-answer.txt";a.click();URL.revokeObjectURL(a.href)});welcome.style.display="none";setTimeout(()=>$("#chat").scrollTop=$("#chat").scrollHeight)}
async function send(text=input.value.trim()){if(!text)return;if(usage>=20){$("#upgradeDialog").showModal();return} input.value=""; $("#chars").textContent="0 / 10000"; addMessage("user",text);history.push({role:"user",content:text}); if(fileText){history.push({role:"user",content:`Attached file content:\n${fileText.slice(0,50000)}`});fileText=""} typing.hidden=false;$("#status").textContent="● Thinking"; try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:history})});const data=await r.json();if(!r.ok)throw new Error(data.error||"AI request failed");const reply=data.reply||"No response.";history.push({role:"assistant",content:reply});addMessage("assistant",reply);usage++;recent.unshift({title:text.slice(0,45),time:new Date().toLocaleString()});recent=recent.slice(0,20);save();updateUsage()}catch(e){addMessage("assistant","Error: "+e.message);toast("AI request failed")}finally{typing.hidden=true;$("#status").textContent="● Ready"}}
function newChat(){history=[];messagesEl.innerHTML="";welcome.style.display="block";save();toast("New chat started")}
$("#send").onclick=()=>send();input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}});input.addEventListener("input",()=>$("#chars").textContent=`${input.value.length} / 10000`);
document.querySelectorAll("[data-prompt]").forEach(b=>b.onclick=()=>{input.value=b.dataset.prompt;input.focus()});
$("#newChat").onclick=$("#headerNew").onclick=newChat;
$("#menu").onclick=()=>$("#sidebar").classList.toggle("open");
$("#headerSettings").onclick=()=>$("#settingsDialog").showModal();
$("#upgrade").onclick=()=>$("#upgradeDialog").showModal();
$("#image").onclick=$("#imageQuick").onclick=()=>$("#imageDialog").showModal();
$("#makeImage").onclick=()=>{const p=$("#imagePrompt").value.trim();if(p){$("#imageDialog").close();input.value=`Create an image of: ${p}`;input.focus();toast("Image prompt added. Your current Gemini text API cannot create the image itself.")}};
$("#attach").onclick=()=>$("#file").click();
$("#file").onchange=async e=>{const f=e.target.files[0];if(!f)return;$("#filePreview").hidden=false;$("#filePreview").textContent=`📎 ${f.name} (${Math.round(f.size/1024)} KB)`;fileText=await f.text().catch(()=>`File selected: ${f.name}`);toast("File attached")};
$("#links").onclick=()=>{const q=input.value.trim();if(!q)return toast("Type something first");window.open("https://www.google.com/search?q="+encodeURIComponent(q),"_blank")};
$("#login").onclick=()=>openAccount("login");$("#signup").onclick=()=>openAccount("signup");
function openAccount(mode){accountMode=mode;$("#accountTitle").textContent=mode==="login"?"Login":"Create Account";$("#accountName").hidden=mode==="login";$("#accountName").required=mode==="signup";$("#accountSubmit").textContent=mode==="login"?"Login":"Create Account";$("#switchAccount").textContent=mode==="login"?"Create Account":"Login";$("#accountDialog").showModal()}
$("#switchAccount").onclick=()=>openAccount(accountMode==="login"?"signup":"login");
$("#accountDialog form").onsubmit=e=>{e.preventDefault();localStorage.setItem("jddhm_account",$("#accountEmail").value);$("#accountDialog").close();toast(accountMode==="login"?"Logged in (local demo)":"Account created (local demo)")};
$("#paid").onclick=()=>{localStorage.setItem("jddhm_paid","true");usage=0;updateUsage();$("#upgradeDialog").close();toast("Payment marked as submitted. Manual verification is required.")};
$("#clear").onclick=()=>{recent=[];save();toast("Recent chats cleared")};
$("#dark").onchange=e=>{document.body.classList.toggle("dark",e.target.checked);localStorage.setItem("dark",e.target.checked)};
$("#large").onchange=e=>{document.body.classList.toggle("large",e.target.checked);localStorage.setItem("large",e.target.checked)};
$("#font").onchange=e=>document.documentElement.style.setProperty("--answer-size",e.target.value+"px");
document.querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>{if(b.dataset.view==="settings")$("#settingsDialog").showModal();else if(b.dataset.view==="recent")toast(recent.length?recent.map(x=>x.title).join(" • "):"No recent chats")});
let t=localStorage.getItem("dark")==="true";$("#dark").checked=t;document.body.classList.toggle("dark",t);let l=localStorage.getItem("large")==="true";$("#large").checked=l;document.body.classList.toggle("large",l);updateUsage();
setTimeout(()=>$("#loadingScreen").remove(),900);

window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;$("#installBtn").hidden=false});
$("#installBtn").onclick=async()=>{if(deferredInstall){deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null}};
